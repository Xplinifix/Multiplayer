const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const players = {}; // Track all connected players

// Serve static files (for the frontend)
app.use(express.static('public'));

// Handle socket connections
io.on('connection', (socket) => {
    console.log(`Player connected: ${socket.id}`);

    // Add new player
    socket.on('newPlayer', (data) => {
        players[socket.id] = { x: 250, y: 250, name: data.name, color: data.color };
        io.emit('updatePlayers', players); // Broadcast updated players
    });

    // Handle player movement
    socket.on('move', (movement) => {
        if (players[socket.id]) {
            const player = players[socket.id];
            if (movement.up) player.y -= 5;
            if (movement.down) player.y += 5;
            if (movement.left) player.x -= 5;
            if (movement.right) player.x += 5;

            // Ensure players stay in bounds
            player.x = Math.max(0, Math.min(470, player.x));
            player.y = Math.max(0, Math.min(470, player.y));

            io.emit('updatePlayers', players);
        }
    });

    // Handle player disconnect
    socket.on('disconnect', () => {
        console.log(`Player disconnected: ${socket.id}`);
        delete players[socket.id];
        io.emit('updatePlayers', players); // Broadcast updated players
    });
});

// Start server
server.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});